import pandas as pd
import numpy as np

def clean_and_repair_cardio_data(raw_df: pd.DataFrame) -> pd.DataFrame:
    """
    Applies the multi-stage clinical data quality protocol:
    1. Identifier elimination (id)
    2. Negative sign error correction (|x|)
    3. 4-digit typo scale repair (missing decimal points divided by 10)
    4. Inverted blood pressure swapping (ap_lo > ap_hi repaired)
    5. Adult physiological plausibility boundary filtering
    """
    df = raw_df.copy()
    
    # 1. Drop identifier
    if 'id' in df.columns:
        df = df.drop(columns=['id'])
        
    # 2. Fix sign errors
    df['ap_hi'] = df['ap_hi'].abs()
    df['ap_lo'] = df['ap_lo'].abs()
    
    # 3. 4-digit typo scale errors (e.g. 1400 -> 140, 1000 -> 100)
    hi_scale_mask = (df['ap_hi'] >= 1000) & (df['ap_hi'] <= 2500)
    df.loc[hi_scale_mask, 'ap_hi'] //= 10
    
    lo_scale_mask = (df['ap_lo'] >= 1000) & (df['ap_lo'] <= 1600)
    df.loc[lo_scale_mask, 'ap_lo'] //= 10
    
    # 4. Swapped Blood Pressure Repair
    swap_mask = (df['ap_hi'] < df['ap_lo']) & (df['ap_lo'] >= 70) & (df['ap_hi'] >= 40)
    df.loc[swap_mask, ['ap_hi', 'ap_lo']] = df.loc[swap_mask, ['ap_lo', 'ap_hi']].values
    
    # 5. Physiological plausibility boundaries
    valid_mask = (
        (df['ap_hi'] >= 70) & (df['ap_hi'] <= 240) &
        (df['ap_lo'] >= 40) & (df['ap_lo'] <= 150) &
        (df['ap_hi'] > df['ap_lo']) &
        (df['height'] >= 135) & (df['height'] <= 215) &
        (df['weight'] >= 35.0) & (df['weight'] <= 180.0)
    )
    return df[valid_mask].copy()

def engineer_clinical_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Formulates clinically validated hemodynamic and metabolic indices:
    - age_years, bmi, pulse_pressure, map
    - pulsatility_index, bsa (Mosteller)
    - metabolic_syndrome score (0 - 4 criteria)
    - athero_risk, lifestyle_risk
    - aha_stage (0=Normal, 1=Elevated, 2=Stage1, 3=Stage2, 4=Crisis)
    """
    df = df.copy()
    
    # Age standardization
    if 'age_years' not in df.columns and 'age' in df.columns:
        df['age_years'] = (df['age'] / 365.25).round(2)
        
    # BMI
    height_m = df['height'] / 100.0
    df['bmi'] = (df['weight'] / (height_m ** 2)).round(2)
    
    # Hemodynamic markers
    df['pulse_pressure'] = df['ap_hi'] - df['ap_lo']
    df['map'] = (df['ap_lo'] + (df['pulse_pressure'] / 3.0)).round(2)
    df['pulsatility_index'] = (df['pulse_pressure'] / df['ap_hi']).round(4)
    
    # Body Surface Area (Mosteller formula)
    df['bsa'] = np.sqrt((df['height'] * df['weight']) / 3600.0).round(3)
    
    # Metabolic Syndrome Score (0 - 4)
    df['metabolic_syndrome'] = (
        (df['bmi'] >= 30.0).astype(int) +
        (df['gluc'] > 1).astype(int) +
        (df['cholesterol'] > 1).astype(int) +
        (df['ap_hi'] >= 130).astype(int)
    )
    
    # Atherogenic interaction
    df['athero_risk'] = df['cholesterol'] * df['gluc']
    
    # Sedentary older smoker index
    df['lifestyle_risk'] = df['smoke'] * (1 - df['active']) * (df['age_years'] >= 50).astype(int)
    
    # AHA/ACC Hypertension Clinical Stages
    conditions = [
        (df['ap_hi'] < 120) & (df['ap_lo'] < 80),
        (df['ap_hi'] >= 120) & (df['ap_hi'] < 130) & (df['ap_lo'] < 80),
        ((df['ap_hi'] >= 130) & (df['ap_hi'] < 140)) | ((df['ap_lo'] >= 80) & (df['ap_lo'] < 90)),
        ((df['ap_hi'] >= 140) & (df['ap_hi'] <= 180)) | ((df['ap_lo'] >= 90) & (df['ap_lo'] <= 120)),
        (df['ap_hi'] > 180) | (df['ap_lo'] > 120)
    ]
    choices = [0, 1, 2, 3, 4]  # Normal, Elevated, Stage 1, Stage 2, Crisis
    df['aha_stage'] = np.select(conditions, choices, default=3)
    
    return df

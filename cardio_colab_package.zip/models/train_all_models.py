import os
import sys
import time
import warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import RobustScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.calibration import calibration_curve
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, precision_recall_curve, average_precision_score,
    confusion_matrix, brier_score_loss, matthews_corrcoef
)

# Optional gradient boosters
try:
    import lightgbm as lgb
except ImportError:
    lgb = None

try:
    import catboost as cb
except ImportError:
    cb = None

try:
    import xgboost as xgb
except ImportError:
    xgb = None

try:
    import shap
except ImportError:
    shap = None

# Import our modular cleaner
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(base_dir, 'models'))
from data_cleaner import clean_and_repair_cardio_data, engineer_clinical_features

def main():
    print("=" * 70)
    print(" CARDIOVASCULAR DIGITAL TWIN — FULL MULTI-MODEL BENCHMARK SUITE")
    print("=" * 70)

    # 1. Load data
    csv_path = os.path.join(base_dir, 'data', 'cardio_train.csv')
    if not os.path.exists(csv_path):
        csv_path = os.path.join(base_dir, 'data', 'cardio_cleaned.csv')
    
    print(f"\n[Phase 1] Ingesting dataset from: {csv_path}")
    with open(csv_path, 'r', encoding='utf-8') as f:
        sep = ';' if ';' in f.readline() else ','
    raw_df = pd.read_csv(csv_path, sep=sep)
    print(f"Loaded {len(raw_df):,} raw records.")

    # 2. Clean & Repair
    print("\n[Phase 2] Executing clinical cleansing & repair...")
    df_clean = clean_and_repair_cardio_data(raw_df)
    print(f"Retained {len(df_clean):,} valid records after repair.")

    # 3. Feature Engineering
    print("\n[Phase 3] Engineering hemodynamic & metabolic features...")
    df_feat = engineer_clinical_features(df_clean)
    
    feature_cols = [
        'age_years', 'gender', 'height', 'weight', 'ap_hi', 'ap_lo',
        'cholesterol', 'gluc', 'smoke', 'alco', 'active', 'bmi',
        'pulse_pressure', 'map', 'pulsatility_index', 'bsa',
        'metabolic_syndrome', 'athero_risk', 'lifestyle_risk', 'aha_stage'
    ]

    X = df_feat[feature_cols].copy()
    y = df_feat['cardio'].copy()
    print(f"Feature matrix: {X.shape[0]:,} rows x {X.shape[1]} features.")

    # 4. Configure Models
    candidate_models = {
        'Logistic Regression': LogisticRegression(max_iter=1000, C=1.0, random_state=42),
        'Decision Tree': DecisionTreeClassifier(max_depth=6, min_samples_leaf=25, random_state=42),
        'Tuned Random Forest': RandomForestClassifier(
            n_estimators=100, max_depth=12, min_samples_split=5,
            min_samples_leaf=2, max_features='sqrt', random_state=42, n_jobs=-1
        )
    }

    if lgb is not None:
        candidate_models['LightGBM'] = lgb.LGBMClassifier(
            n_estimators=500, learning_rate=0.03, num_leaves=45, max_depth=7,
            subsample=0.8, colsample_bytree=0.8, random_state=42, verbosity=-1, n_jobs=-1
        )

    if cb is not None:
        candidate_models['CatBoost'] = cb.CatBoostClassifier(
            iterations=500, learning_rate=0.04, depth=6, random_seed=42,
            verbose=0, thread_count=-1
        )

    if xgb is not None:
        candidate_models['XGBoost'] = xgb.XGBClassifier(
            n_estimators=450, learning_rate=0.03, max_depth=6, subsample=0.8,
            colsample_bytree=0.8, random_state=42, eval_metric='logloss', n_jobs=-1
        )

    # 5. Stratified 5-Fold Evaluation
    print("\n[Phase 4] Running Stratified 5-Fold Cross-Validation...")
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    model_names = list(candidate_models.keys()) + ['Stacking Ensemble']
    
    oof_probs = {m: np.zeros(len(X)) for m in model_names}
    fit_times = {m: 0.0 for m in model_names}

    for fold, (train_idx, val_idx) in enumerate(skf.split(X, y), 1):
        print(f"  --> Processing Fold {fold}/5...")
        X_tr, y_tr = X.iloc[train_idx], y.iloc[train_idx]
        X_va, y_va = X.iloc[val_idx], y.iloc[val_idx]

        # Scaler for linear model
        scaler = RobustScaler()
        X_tr_s = scaler.fit_transform(X_tr)
        X_va_s = scaler.transform(X_va)

        fold_preds = {}
        for name, model in candidate_models.items():
            t0 = time.time()
            if name == 'Logistic Regression':
                model.fit(X_tr_s, y_tr)
                p = model.predict_proba(X_va_s)[:, 1]
            else:
                model.fit(X_tr, y_tr)
                p = model.predict_proba(X_va)[:, 1]
            fit_times[name] += (time.time() - t0)
            oof_probs[name][val_idx] = p
            fold_preds[name] = p

        # Stacking blend
        weights = []
        preds_list = []
        if 'Tuned Random Forest' in fold_preds:
            weights.append(0.20)
            preds_list.append(fold_preds['Tuned Random Forest'])
        if 'LightGBM' in fold_preds:
            weights.append(0.35)
            preds_list.append(fold_preds['LightGBM'])
        if 'CatBoost' in fold_preds:
            weights.append(0.30)
            preds_list.append(fold_preds['CatBoost'])
        if 'XGBoost' in fold_preds:
            weights.append(0.15)
            preds_list.append(fold_preds['XGBoost'])

        if preds_list:
            w_norm = np.array(weights) / sum(weights)
            stack_p = sum(w * p for w, p in zip(w_norm, preds_list))
            oof_probs['Stacking Ensemble'][val_idx] = stack_p

    # 6. Compute Metrics
    print("\n[Phase 5] Compiling Comprehensive Metrics Table...")
    rows = []
    threshold = 0.50
    for name in model_names:
        p = oof_probs[name]
        preds = (p >= threshold).astype(int)
        tn, fp, fn, tp = confusion_matrix(y, preds).ravel()

        rows.append({
            'Model Architecture': name,
            'Accuracy': round(accuracy_score(y, preds), 4),
            'Precision': round(precision_score(y, preds), 4),
            'Recall (Sens)': round(recall_score(y, preds), 4),
            'Specificity': round(tn / (tn + fp), 4),
            'F1-Score': round(f1_score(y, preds), 4),
            'AUC-ROC': round(roc_auc_score(y, p), 4),
            'PR-AUC': round(average_precision_score(y, p), 4),
            'MCC': round(matthews_corrcoef(y, preds), 4),
            'Brier Score': round(brier_score_loss(y, p), 4),
            'Fit Time (s)': round(fit_times[name], 2)
        })

    metrics_df = pd.DataFrame(rows).sort_values(by='AUC-ROC', ascending=False).reset_index(drop=True)
    
    # Save metrics
    out_csv = os.path.join(base_dir, 'models', 'models_comparison_metrics.csv')
    metrics_df.to_csv(out_csv, index=False)
    print(f"Saved metric comparisons to: {out_csv}")
    print("\n" + metrics_df.to_string(index=False))

    # 7. Generate High-Res Figures
    print("\n[Phase 6] Generating publication-grade figures (300 DPI)...")
    fig_dir = os.path.join(base_dir, 'diagrams', 'figures')
    os.makedirs(fig_dir, exist_ok=True)

    # ROC Curves
    plt.figure(figsize=(9, 7), dpi=300)
    for name in model_names:
        fpr, tpr, _ = roc_curve(y, oof_probs[name])
        auc_v = roc_auc_score(y, oof_probs[name])
        plt.plot(fpr, tpr, lw=2, label=f"{name} (AUC = {auc_v:.4f})")
    plt.plot([0, 1], [0, 1], 'k--', lw=1.5, label="No Skill (AUC = 0.5000)")
    plt.xlabel("False Positive Rate (1 - Specificity)", fontweight='bold')
    plt.ylabel("True Positive Rate (Sensitivity)", fontweight='bold')
    plt.title("Multi-Model ROC Benchmarks", fontweight='bold')
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(os.path.join(fig_dir, "roc_curves_comparison.png"), dpi=300)
    plt.close()

    # Bar chart
    plt.figure(figsize=(12, 6), dpi=300)
    plot_df = metrics_df.melt(id_vars=['Model Architecture'], value_vars=['Accuracy', 'Precision', 'Recall (Sens)', 'F1-Score', 'AUC-ROC'])
    sns.barplot(data=plot_df, x='Model Architecture', y='value', hue='variable', palette='viridis')
    plt.ylim(0.55, 0.85)
    plt.title("Model Metrics Comparison", fontweight='bold')
    plt.xticks(rotation=20, ha='right', fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(fig_dir, "metric_benchmark_barchart.png"), dpi=300)
    plt.close()

    # 8. Train & Save Best Model on Full Cohort
    print("\n[Phase 7] Fitting & persisting final production model...")
    best_name = metrics_df.iloc[0]['Model Architecture']
    if best_name in candidate_models:
        best_model = candidate_models[best_name]
    else:
        best_model = candidate_models['Tuned Random Forest']

    best_model.fit(X, y)
    best_path = os.path.join(base_dir, 'models', 'best_cardio_model.joblib')
    joblib.dump(best_model, best_path)
    print(f"Persisted best model ({best_name}) to: {best_path}")
    print("\nAll pipeline tasks completed successfully!")

if __name__ == '__main__':
    main()
